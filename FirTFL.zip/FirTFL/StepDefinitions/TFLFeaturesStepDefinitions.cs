using System;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using Gherkin.CucumberMessages.Types;
using LivingDoc.Dtos;

namespace FirTFL.StepDefinitions
{
    [Binding]
    public class DebugStepDefinitions
    {

        WebDriver d = new ChromeDriver(Environment.CurrentDirectory);

        [Given(@"Plan a journey page is open")]
        public void GivenPlanAJourneyPageIsOpen()
        {
            d.Navigate().GoToUrl("https://tfl.gov.uk/plan-a-journey/");
            d.Manage().Window.Maximize();
            try
            {
                d.FindElement(By.XPath("//button/strong[text()='Accept all cookies']")).Click();
                d.FindElement(By.XPath("//button/strong[text()='Done']")).Click();
            }
            catch { }
        }

        [When(@"valid From and To is entered")]
        public void WhenValidFromAndToIsEntered()
        {
            d.FindElement(By.Id("InputFrom")).SendKeys("Ilford rail station");
            d.FindElement(By.Id("InputTo")).SendKeys(Keys.Tab);
            d.FindElement(By.Id("InputTo")).SendKeys("Woking");
            d.FindElement(By.Id("InputTo")).SendKeys(Keys.Tab);
            d.FindElement(By.Id("plan-journey-button")).Click();
            Thread.Sleep(5000);
        }

        [Then(@"journey result is displayed")]
        public void ThenJourneyResultIsDisplayed()
        {
            bool v1 = false;
            try {  v1 = d.FindElement(By.XPath("//h2[contains(.,\"Fastest by public transport\")]")).Displayed; 
                if (v1 == false)
             Assert.Fail(); } catch { } finally { d.Quit(); }
        }

        [When(@"invalid From and To is entered")]
        public void WhenInvalidFromAndToIsEntered()
        {
            d.FindElement(By.Id("InputFrom")).SendKeys("+++");
            d.FindElement(By.Id("InputTo")).SendKeys(Keys.Tab);
            d.FindElement(By.Id("InputTo")).SendKeys("+++");
            d.FindElement(By.Id("InputTo")).SendKeys(Keys.Tab);
            d.FindElement(By.Id("plan-journey-button")).Click();
            Thread.Sleep(5000);
        }

        [Then(@"invalid journey result display")]
        public void ThenInvalidJourneyResultDisplay()
        {
            bool v1 = false;
            try
            {
                v1 = d.FindElement(By.XPath("//li[contains(.,\"Journey planner could not find any results to your search. Please try again\")]")).Displayed;
                if (v1 == false)
                    Assert.Fail();
            }             catch { }             finally { d.Quit(); }
        } 


        [When(@"From and To is empty")]
        public void WhenFromAndToIsEmpty()
        {

            d.FindElement(By.Id("plan-journey-button")).Click();
            Thread.Sleep(5000);
        }

        [Then(@"Validation error is displayed")]
        public void ThenValidationErrorIsDisplayed()
        {
            bool v1 = false;
            try { v1 = d.FindElement(By.XPath("//*[@id=\"InputFrom-error\"]")).Displayed;
                if (v1 == false)
                    Assert.Fail();
            } catch { } finally { d.Quit(); }
        }

        [Given(@"Journey results page is displayed")]
        public void GivenJourneyResultsPageIsDisplayed()
        {
            d.Navigate().GoToUrl("https://tfl.gov.uk/plan-a-journey/");
            d.Manage().Window.Maximize();
            try
            {
                d.FindElement(By.XPath("//button/strong[text()='Accept all cookies']")).Click();
                d.FindElement(By.XPath("//button/strong[text()='Done']")).Click();
            }
            catch { }

            d.FindElement(By.Id("InputFrom")).SendKeys("ilford rail station");
            d.FindElement(By.Id("InputTo")).SendKeys(Keys.Tab);
            d.FindElement(By.Id("InputTo")).SendKeys("Woking");
            d.FindElement(By.Id("InputTo")).SendKeys(Keys.Tab);
            d.FindElement(By.Id("plan-journey-button")).Click();

            Thread.Sleep(5000);

        }
        [When(@"Navigating back to Plan a journey page")]
        public void WhenNavigatingBackToPlanAJourneyPage()
        {
            d.FindElement(By.XPath("//ol/li/a[contains(.,\"Plan a journey\")]")).Click();
        }

        [Then(@"Recent journey tab is displayed")]
        public void ThenRecentJourneyTabIsDisplayed()
        {
            bool v1 = false;
            try
            {
                System.Diagnostics.Debug.WriteLine("Checking if Recents page is displayed");
                d.FindElement(By.Id("jp-recent-tab-jp")).Click();
                v1 = d.FindElement(By.XPath("//a[contains(@class, 'turn-off-recent-journeys')]")).Displayed;
                if (v1 == false)
                { Assert.Fail(); }
            }
            catch { }
            finally
            {
                d.Quit();
            }

        }
        [When(@"Edit Journey is clicked")]
        public void WhenEditJourneyisclickedy()
        {
            d.FindElement(By.XPath("//*[contains(text(),'Edit journey')]")).Click();
            Thread.Sleep(5000);
        }

        [Then(@"Update Journey Button should displayed")]
        public void ThenUpdateJourneyButtonShouldDisplayed()
        {
            bool v1 = false;
            try
            {
               v1 =  d.FindElement(By.XPath("//*[@id=\"plan-journey-button\"]")).Displayed;
                if (v1 == false)
                    Assert.Fail();
            }
            catch { }
            finally { d.Quit(); }
        }
    }
}
